	
	
	<?php

class UssdController 
{
    public function index()
    {
    	# get request SessionId, Mobile, Operator and Type from Hubtel
    	$ussdRequest = json_decode(@file_get_contents('php://input'));
    	$ussdResponse = [];
    	# check if request != null
    	if ($ussdRequest != null)
    	{
    		# get the request type
    		switch ($ussdRequest->Type) 
	    	{
	    		# initial request
	    		case 'Initiation':
	    			$ussdResponse['Message'] = "Welcome to KNUST\n\n1. Continue\n2. Cancel";
	    			
					UssdUser::create([
						'session_id' => $ussdRequest->SessionId,
						'mobile_number' => $ussdRequest->Mobile,
						'mobile_network' => $ussdRequest->Operator,
					]);
					$ussdResponse['ClientState'] = 'enter-name';
					$ussdResponse['Type'] = 'Response';
	    		break;
	    		# continuning request
	    		case 'Response':
	    			switch ($ussdRequest->Sequence)
	    			{
    					case 2:
    						switch ($ussdRequest->ClientState)
    						{
    							case 'enter-name':
    								# check if input == 1 -> continue from welcome menu
    								if ($ussdRequest->Message == '1')
    								{
    									$ussdResponse['Message'] = "Enter your Full Name\n\n";
				    					$ussdResponse['ClientState'] = 'enter-age';
				    					$ussdResponse['Type'] = 'Response';
    								}
    								# check if input == 2 -> cancel from welcome menu
    								elseif ($ussdRequest->Message == '2')
    								{
    									$ussdResponse['Message'] = "Process cancelled.";
										$ussdResponse['Type'] = 'Release';
    								}
    								else
    								{
    									$ussdResponse['Message'] = 'Invalid selection.';
    									$ussdResponse['Type'] = 'Release';
    								}
    							break;
    							
    							default:
    								$ussdResponse['Message'] = 'Invalid selection.';
    								$ussdResponse['Type'] = 'Release';
    							break;
    						}
	    				break;
	    				case 3:
	    					switch ($ussdRequest->ClientState)
	    					{
	    						case 'enter-age':
    								# check if input !empty
    								if (!empty($ussdRequest->Message))
    								{
    									# save fullname in DB
	    								UssdUser::where('session_id', $ussdRequest->SessionId)
	    									->update(['fullname' => $ussdRequest->Message]);
	    								$ussdResponse['Message'] = "Enter your age\n\n";
				    					$ussdResponse['ClientState'] = 'display-summary';
				    					$ussdResponse['Type'] = 'Response';
    								}
    								else
    								{
    									$ussdResponse['Message'] = 'Invalid selection.';
	    								$ussdResponse['Type'] = 'Release';
    								}
    							break;
	    						
	    						default:
	    							$ussdResponse['Message'] = 'Invalid selection.';
	    							$ussdResponse['Type'] = 'Release';
	    						break;
	    					}
	    				break;
	    				case 4:
	    					switch ($ussdRequest->ClientState)
	    					{
	    						case 'display-summary':
    								# check if input !empty
    								if (!empty($ussdRequest->Message))
    								{
    									# save age in DB
	    								UssdUser::where('session_id', $ussdRequest->SessionId)
	    									->update(['age' => $ussdRequest->Message]);
	    								# get student fullname and age from DB
	    								$student = UssdUser::select('fullname', 'age')
	    									->where('session_id', $ussdRequest->SessionId)
	    									->first();
	    								$ussdResponse['Message'] = "Summary\n\nName: $student->fullname\nAge: $student->age";
				    					$ussdResponse['Type'] = 'Release';
    								}
    								else
    								{
    									$ussdResponse['Message'] = 'Invalid selection.';
	    								$ussdResponse['Type'] = 'Release';
    								}
    							break;
	    						
	    						default:
	    							$ussdResponse['Message'] = 'Invalid selection.';
	    							$ussdResponse['Type'] = 'Release';
	    						break;
	    					}
	    				break;
	    				
	    				default:
							$ussdResponse['Message'] = 'Unexpected request.';
							$ussdResponse['Type'] = 'Release';
						break;
	    			}
	    		break;
	    	}
    	}
    	else
    	{
			$ussdResponse['Message'] = 'Invalid USSD request.';
			$ussdResponse['Type'] = 'Release';
    	}
    	header('Access-Control-Allow-Origin: *');
    	header('Content-type: application/json; charset=utf-8');
		echo json_encode($ussdResponse);
    }
}