<?php


header('Content-type: application/json; charset=utf-8'); 
$ussdRequest = json_decode(@file_get_contents('php://input')); 

    // Check if no errors occured. 
    if ($ussdRequest != NULL) { 

    // Create a response object. 
    $ussdResponse = new stdClass; 

    // Set the message to display. 
    $ussdResponse->Message = "Hello world $ussdRequest->Mobile"; 

    // Set the type of this response. 
    $ussdResponse->Type = "Release"; 

  // Encode the response object as JSON and send. 
  echo json_encode($ussdResponse); 
}

?>